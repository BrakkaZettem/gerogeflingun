from telethon import TelegramClient, events

# Replace these with your own values
api_id = '20001746'
api_hash = 'ad25ff9fc57305256ab13ea27c611424'
bot_token = 'YOUR_BOT_TOKEN'  # If you're using a bot, otherwise omit this line

# Create the client and connect
client = TelegramClient('@UniBlueJordans', api_id, api_hash)

# If you're using a bot, start the client with the bot token
# client = TelegramClient('bot', api_id, api_hash).start(bot_token=bot_token)


message = "Sup broski we have regular (15k vids) for 30$ or premium (35k vids) for 50$. It has all the albums of the people in Nintendo DS. Here is the payment info:  Paypal: chastanamandine@gmail.com friends and family only, Bitcoin: 1FwTUMeqkT87XYMZ3EXPZR9hzEBHHs3zSj, Litecoin: LYf1JhDLSrg8TWiUZ7BpYsZT3xyQnocfpw, Ethereum: 0x5e66bFA51A6f4f64c2deBaAf741E85529c2f6818. After sending the payment i will get a notification and come online asap also send a screenshot of payment."

sent_users = set()

@client.on(events.NewMessage)
async def handler(event):
    # Check if the message is a private message
    if event.is_private:
        sender_id = event.sender_id
        if sender_id not in sent_users:
            await event.respond(message)
            sent_users.add(sender_id)

def main():
    client.start()
    print('Bot is running...')
    client.run_until_disconnected()

if __name__ == '__main__':
    main()
