import json
from flask import Flask, render_template, request, redirect
import json
import os
import threading

def get_session_data():
    with open("sessions.json", "r") as f:
        return json.load(f)

def get_user_session_data(user):
    with open("sessions.json", "r") as f:
        data = json.load(f)
    for account in data:
        if account["username"] == user:
            return account["sessions"]


def get_autoresponder_data():
    with open("responderconfig.json", "r") as f:
        return json.load(f)

def get_user_autoresponder_data(user):
    with open("accounts.json", "r") as f:
        data =  json.load(f)
    for account in data:
        if account["username"] == user:
            return account["respondersettings"]


def get_autoposterconfig():
    with open("autoposterconfig.json", "r") as f:
        return json.load(f)



app = Flask(__name__)

#request.form['submit']



def toggle_mute(user_id):
    with open("sessions.json", 'r') as f:
        data = json.load(f)

    for session in data:
        if str(session['user_id']) == user_id:
            if session['muted'] == False:
                session['muted'] = True
            else:
                session['muted'] = False
    with open("sessions.json", 'w') as f:
        json.dump(data, f, indent=4)

def toggle_user_mute(user_id, user):
    with open("sessions.json", 'r') as f:
        data = json.load(f)

    for account in data:
        if account["username"] == user:
            for session in account["sessions"]:
                if str(session['user_id']) == user_id:
                    if session['muted'] == False:
                        session['muted'] = True
                    else:
                        session['muted'] = False
    with open("sessions.json", 'w') as f:
        json.dump(data, f, indent=4)

def save_autoresponder_data(gpt_key, prompt, price, cashapp, bitcoin, litecoin, ethereum):
    with open("responderconfig.json", "r") as f:
        data = json.load(f)
    print(data)
    data['gpt_key'] = gpt_key
    data['prompt'] = prompt
    data['price'] = price
    data['cashapp'] = cashapp
    data['bitcoin'] = bitcoin
    data['litecoin'] = litecoin
    data['ethereum'] = ethereum
    with open("responderconfig.json", "w") as f:
        json.dump(data, f, indent=4)

def save_user_autoresponder_data(gpt_key, prompt, price, cashapp, bitcoin, litecoin, ethereum, user):
    with open("accounts.json", "r") as f:
        data = json.load(f)
    for account in data:
        if account["username"] == user: 
            print(data)
            account["respondersettings"]['gpt_key'] = gpt_key
            account["respondersettings"]['prompt'] = prompt
            account["respondersettings"]['price'] = price
            account["respondersettings"]['cashapp'] = cashapp
            account["respondersettings"]['bitcoin'] = bitcoin
            account["respondersettings"]['litecoin'] = litecoin
            account["respondersettings"]['ethereum'] = ethereum
    with open("accounts.json", "w") as f:
        json.dump(data, f, indent=4)

def save_autoposter_data(upload_every, custom_message, custom_message_frequency, custom_message2, custom_message2_frequency, channel):
    with open("autoposterconfig.json", "r") as f:
        data = json.load(f)
    print(data)
    data['upload_every'] = upload_every
    data['custom_message'] = custom_message
    data['custom_message_frequency'] = custom_message_frequency
    data['custom_message2'] = custom_message2
    data['custom_message2_frequency'] = custom_message2_frequency
    data['channel'] = channel
    with open("autoposterconfig.json", "w") as f:
        json.dump(data, f, indent=4)

def get_user_autopost_settings(user):
    with open("accounts.json", 'r') as f:
        data = json.load(f)
    for account in data:
        if account["username"] == user:
            return account

def save_user_autoposter_data(upload_every, custom_message, custom_message_frequency, custom_message2, custom_message2_frequency, channel, user):
    with open("accounts.json", "r") as f:
        data = json.load(f)

    for account in data:
        if account["username"] == user:
            account["postersettings"]['upload_every'] = upload_every
            account["postersettings"]['custom_message'] = custom_message
            account["postersettings"]['custom_message_frequency'] = custom_message_frequency
            account["postersettings"]['custom_message2'] = custom_message2
            account["postersettings"]['custom_message2_frequency'] = custom_message2_frequency
            account["postersettings"]['channel'] = channel
    with open("accounts.json", "w") as f:
        json.dump(data, f, indent=4)

def get_all_users():
    usernames = []
    with open("accounts.json", 'r') as f:
        data = json.load(f)
    for account in data:
        usernames.append(account["username"])
    return usernames


UPLOAD_FOLDER = 'liloutput'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/upload', methods=['GET', 'POST'])
def upload_files():
    if request.method == 'POST':
        print(request.form['submit'])
        if request.form['submit'] == "Upload":
            # Check if the POST request has file parts
            if 'file' not in request.files:
                return redirect(request.url)

            files = request.files.getlist('file')

            # Iterate over the uploaded files
            for file in files:
                # If the user does not select a file, the browser submits an empty file
                if file.filename == '':
                    continue

                # Check if the file is allowed (for example, only allow .txt files)
                # You can add more file extensions as needed
                if file:
                    filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
                    file.save(filename)
            return redirect("/upload")
        elif request.form['submit'] == "UploadAlbum":
            print("cock")
            if 'file' not in request.files:
                return redirect(request.url)

            files = request.files.getlist('file')
            os.makedirs(f"{app.config['UPLOAD_FOLDER']}/{request.form['message']}")

            # Iterate over the uploaded files
            for file in files:
                # If the user does not select a file, the browser submits an empty file
                if file.filename == '':
                    continue
                if file:
                    filename = os.path.join(f"{app.config['UPLOAD_FOLDER']}/{request.form['message']}", file.filename)
                    file.save(filename)
            return redirect("/upload")

        else:
            save_autoposter_data(request.form['upload_every'],request.form['custom_message'],request.form['custom_message_frequency'],request.form['custom_message2'],request.form['custom_message2_frequency'],request.form['channel'])
            print("kkr")

    return render_template('upload.html', file_amount=len(os.listdir('liloutput')), users=get_all_users())


@app.route('/autopostersettings/<username>', methods=['GET', 'POST'])
def autopostersettings(username):
    if request.method == 'POST':
        save_user_autoposter_data(request.form['upload_every'],request.form['custom_message'],request.form['custom_message_frequency'],request.form['custom_message2'],request.form['custom_message2_frequency'],request.form['channel'], username)
    return render_template('autopostsettings.html', data=get_user_autopost_settings(username)["postersettings"])



@app.route('/autorespondersettings/<username>', methods =["GET", "POST"])
def autorespondersettings(username):
    if request.method == "POST":
        save_user_autoresponder_data(request.form['gpt_key'],request.form['prompt'],request.form['price'],request.form['cashapp'],request.form['bitcoin'],request.form['litecoin'],request.form['ethereum'],username)
        print('aa')
    return render_template('autorespondersettings.html', data=get_user_autoresponder_data(username))


@app.route('/<username>', methods =["GET", "POST"])
def display_accounts(username):
    if request.method == "POST":
        print(request.form['submit'])
        toggle_user_mute(str(request.form['submit']), username)
    session_data = get_user_session_data(username)
    return render_template('index.html', data=session_data)



if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port='80')
